# users/views.py

from rest_framework import generics, permissions, status
from rest_framework.response import Response
from .models import User
from .serializers import UserSerializer, CreateUserSerializer
from .permissions import IsSuperAdmin, IsAdmin, IsCompany

class CreateUserView(generics.CreateAPIView):
    queryset = User.objects.all()
    serializer_class = CreateUserSerializer
    permission_classes = [permissions.IsAuthenticated]

    def perform_create(self, serializer):
        role = self.request.data.get('role')

        if self.request.user.role == 'superadmin':
            pass  # allowed all
        elif self.request.user.role == 'admin' and role not in ['company', 'candidate']:
            raise PermissionError("Admin can only create company or candidate.")
        elif self.request.user.role == 'company' and role != 'candidate':
            raise PermissionError("Company can only create candidate.")
        elif self.request.user.role == 'candidate':
            raise PermissionError("Candidate cannot create users.")
        
        serializer.save(created_by=self.request.user)

class UserListView(generics.ListAPIView):
    queryset = User.objects.all()
    serializer_class = UserSerializer
    permission_classes = [permissions.IsAuthenticated]

    def get_queryset(self):
        user = self.request.user
        if user.role == 'superadmin':
            return User.objects.exclude(id=user.id)
        elif user.role == 'admin':
            return User.objects.exclude(role='superadmin')
        elif user.role == 'company':
            return User.objects.filter(created_by=user)
        elif user.role == 'candidate':
            return User.objects.filter(id=user.id)
        return User.objects.none()

class UserDetailView(generics.RetrieveUpdateDestroyAPIView):
    queryset = User.objects.all()
    serializer_class = UserSerializer
    permission_classes = [permissions.IsAuthenticated]
