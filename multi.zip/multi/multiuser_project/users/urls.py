# users/urls.py

from django.urls import path
from .views import CreateUserView, UserListView, UserDetailView

urlpatterns = [
    path('create/', CreateUserView.as_view(), name='user-create'),
    path('list/', UserListView.as_view(), name='user-list'),
    path('<int:pk>/', UserDetailView.as_view(), name='user-detail'),
]
